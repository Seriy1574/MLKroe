create definer = root@localhost trigger change_null
    before UPDATE
    on products
    for each row
BEGIN
    IF (new.name IS NULL and new.description IS NULL) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Вставили два пустых значения, вставка отмененна"!!';
    END IF ;
END;

