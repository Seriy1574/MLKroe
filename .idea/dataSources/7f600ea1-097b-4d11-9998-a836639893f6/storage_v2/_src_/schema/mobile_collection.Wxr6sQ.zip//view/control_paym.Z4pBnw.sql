create definer = root@localhost view control_paym as
select date_format(`ae`.`date_action`, '%d.%m.%Y')      AS `Дата`,
       concat(`pe`.`last_name`, ' ', `pe`.`first_name`) AS `Сотрудник`,
       concat(`c`.`last_name`, ' ', `c`.`first_name`)   AS `Клиент`,
       `ta`.`name`                                      AS `Тип активности сотрудника`,
       `ra`.`name`                                      AS `Результат`
from (((((`mobile_collection`.`actions_employees` `ae` join `mobile_collection`.`clients` `c` on ((`ae`.`id_client` = `c`.`id`))) join `mobile_collection`.`accounts` `a` on ((`c`.`id` = `a`.`id_client`))) join `mobile_collection`.`profiles_employeers` `pe` on ((`ae`.`id_employee` = `pe`.`id`))) join `mobile_collection`.`types_actions` `ta` on ((`ae`.`id_type_action` = `ta`.`id`)))
         join `mobile_collection`.`results_actions` `ra` on ((`ra`.`id` = `ae`.`id_result_action`)));

