create definer = root@localhost view view_products as
select `p`.`name` AS `name`, `c`.`name` AS `name`
from (`lesson5_1`.`products` `p`
         left join `lesson5_1`.`catalogs` `c` on ((`p`.`catalog_id` = `c`.`id`)));

-- comment on column view_products.pruduct not supported: Название

-- comment on column view_products.type not supported: Название раздела

