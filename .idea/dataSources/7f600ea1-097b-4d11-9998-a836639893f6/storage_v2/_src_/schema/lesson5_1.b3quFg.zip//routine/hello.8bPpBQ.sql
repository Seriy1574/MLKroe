create
    definer = root@localhost function hello() returns varchar(100)
BEGIN
    DECLARE hi_men VARCHAR(100);
    SET hi_men =
            (SELECT
                 IF (((CURTIME() + INTERVAL 3 HOUR > '06:00:00') and  (CURTIME() + INTERVAL 3 HOUR <= '12:00:00')),"Доброе утро!",
                     IF (((CURTIME() + INTERVAL 3 HOUR > '12:00:00') and  (CURTIME() + INTERVAL 3 HOUR <= '18:00:00')),"Добрый день!",
                         IF (((CURTIME() + INTERVAL 3 HOUR > '18:00:00') and  (CURTIME() + INTERVAL 3 HOUR <= '23:59:59')),"Добрый вечер!","Доброй ночи"))));
    RETURN hi_men;
END;

