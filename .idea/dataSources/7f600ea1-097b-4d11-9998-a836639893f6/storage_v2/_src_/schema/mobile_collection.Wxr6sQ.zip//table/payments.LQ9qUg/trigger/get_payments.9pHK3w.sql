create definer = root@localhost trigger get_payments
    after INSERT
    on payments
    for each row
BEGIN
    IF NEW.sum_payment IS NOT NULL then
        UPDATE accounts SET sum_dept = sum_dept - NEW.sum_payment WHERE accounts.id = NEW.id;
    END IF ;
END;

