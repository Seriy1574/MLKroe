create
    definer = root@localhost function hello() returns varchar(100)
BEGIN
    DECLARE hi_men VARCHAR(100);
    SET hi_men = (SELECT
                 IF ((CURTIME() > "06:00:00" and  CURTIME() <= "12:00:00"),"Доброе утро!",
                 IF ((CURTIME() > "12:00:00" and  CURTIME() <= "18:00:00"),"Добрый день",
                 IF ((CURTIME() > "18:00:00" and  CURTIME() <= "00:00:00"),"Добрый вечер!","Доброй ночи"))));
    RETURN hi_men;
END;

